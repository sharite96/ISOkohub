const products=[
{name:'Smartphone Pro',cat:'Electronics',price:'$299',icon:'📱'},
{name:'Classic Sneakers',cat:'Fashion',price:'$59',icon:'👟'},
{name:'Modern Chair',cat:'Home',price:'$85',icon:'🪑'},
{name:'Beauty Care Set',cat:'Beauty',price:'$35',icon:'💄'},
{name:'City Car',cat:'Vehicles',price:'$8,900',icon:'🚗'},
{name:'Design Service',cat:'Services',price:'$25',icon:'🛠️'}];
let cart=[];
function render(list){document.getElementById('grid').innerHTML=list.map((p,i)=>`<article class="card"><div class="pic">${p.icon}</div><div class="info"><b>${p.name}</b><p>${p.cat}</p><p class="price">${p.price}</p><button class="buy" onclick="add(${i})">Add to cart</button></div></article>`).join('')}
function add(i){cart.push(products[i]);document.getElementById('cartCount').textContent=cart.length;alert(products[i].name+' added to cart.');}
function openCart(){alert(cart.length?`Cart has ${cart.length} item(s). Checkout will be connected to live payments in the production version.`:'Your cart is empty.');}
function filter(cat){render(products.filter(p=>p.cat===cat));document.getElementById('products').scrollIntoView({behavior:'smooth'});}
function searchProducts(){const q=document.getElementById('search').value.toLowerCase();render(products.filter(p=>(p.name+p.cat).toLowerCase().includes(q)));}
render(products);
